const READER_PROTOCOL = "reader/1";
const RUMOR_KIND = 30078;
const SYNC_WINDOW_DAYS = 10;
const MAX_COMPRESSED_BYTES = 5 * 1024 * 1024;
const MAX_CHUNKS = 512;
const MAX_TITLE_LEN = 500;
const MAX_URL_LEN = 2e3;
function canonicalize(input) {
  const nfc = input.normalize("NFC");
  const lf = nfc.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const lines = lf.split("\n").map((l) => l.replace(/[ \t]+$/g, ""));
  const collapsed = [];
  let blanks = 0;
  for (const l of lines) {
    if (l.trim() === "") {
      blanks += 1;
      if (blanks <= 2) collapsed.push("");
    } else {
      blanks = 0;
      collapsed.push(l);
    }
  }
  return collapsed.join("\n").replace(/^\n+|\n+$/g, "") + "\n";
}
function escapePlainText(input) {
  return input.replace(/([\\`*_{}[\]()#+\-!|>])/g, "\\$1");
}
async function sha256HexBytes(bytes) {
  const d = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function documentId(canonical) {
  return sha256HexBytes(new TextEncoder().encode(canonical));
}
function syncSince(nowSecs) {
  return nowSecs - SYNC_WINDOW_DAYS * 86400;
}
function wordCount(canonical) {
  let inFence = false;
  let n = 0;
  for (const line of canonical.split("\n")) {
    const t = line.trim();
    if (t.startsWith("```")) {
      inFence = !inFence;
      continue;
    }
    if (inFence) continue;
    for (const w of t.split(/\s+/)) {
      if (!w) continue;
      if (w.startsWith("http://") || w.startsWith("https://")) continue;
      if (/^[-*+>]+$/.test(w) || /^\d+[.)]$/.test(w)) continue;
      n += 1;
    }
  }
  return n;
}
function checkLimits(args) {
  if (args.compressedBytes > MAX_COMPRESSED_BYTES) throw new Error("compressed transfer exceeds 5 MiB");
  if (args.chunkCount > MAX_CHUNKS) throw new Error("chunk count exceeds 512");
  if (args.titleLen > MAX_TITLE_LEN) throw new Error("title too long");
  if (args.urlLen > MAX_URL_LEN) throw new Error("url too long");
}
export {
  READER_PROTOCOL as R,
  RUMOR_KIND as a,
  checkLimits as b,
  canonicalize as c,
  documentId as d,
  escapePlainText as e,
  syncSince as s,
  wordCount as w
};
