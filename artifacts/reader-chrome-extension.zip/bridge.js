window.addEventListener("message", async (ev) => {
  if (ev.source !== window || !ev.data || ev.data.ns !== "reader-nip07") return;
  const { id, method, event } = ev.data;
  try {
    const nostr = window.nostr;
    if (!nostr) throw new Error("no browser signer");
    if (method === "getPublicKey") {
      const pubkey = await nostr.getPublicKey();
      window.postMessage({ ns: "reader-nip07", id, ok: true, pubkey }, "*");
    } else if (method === "signProof" && event) {
      const signed = await nostr.signEvent(event);
      window.postMessage({ ns: "reader-nip07", id, ok: true, event: signed }, "*");
    } else {
      throw new Error("unsupported method");
    }
  } catch (e) {
    window.postMessage({ ns: "reader-nip07", id, ok: false, error: String(e).slice(0, 200) }, "*");
  }
});
