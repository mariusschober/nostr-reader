import "./modulepreload-polyfill-DaKOjhqt.js";
const s = await chrome.runtime.sendMessage({ kind: "reader-status" });
document.getElementById("status").innerHTML = s.paired ? `<span class="ok">Connected</span> · ${s.relays.length} relays · ${s.pending} pending` : `<span class="warn">Not paired</span> — scan with Reader on Android`;
document.getElementById("open").onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL("src/ui/pairing.html") });
document.getElementById("retry").onclick = async () => {
  await chrome.runtime.sendMessage({ kind: "reader-retry" });
  location.reload();
};
