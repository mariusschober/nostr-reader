import "./modulepreload-polyfill-DaKOjhqt.js";
const s = await chrome.runtime.sendMessage({ kind: "reader-status" });
document.getElementById("dev").textContent = s.paired ? "Connected · " + s.relays.join(", ") : "Not paired";
document.getElementById("pend").textContent = String(s.pending);
